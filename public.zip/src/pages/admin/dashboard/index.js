import React from 'react';
import BarChar from '../../../components/BarCharts.js';
import PieCharts from '../../../components/PieCharts.js';
const DashboardPage = () => {
  return <>
    Dashboard
    <BarChar />
    <PieCharts />
  </>;
};

export default DashboardPage;